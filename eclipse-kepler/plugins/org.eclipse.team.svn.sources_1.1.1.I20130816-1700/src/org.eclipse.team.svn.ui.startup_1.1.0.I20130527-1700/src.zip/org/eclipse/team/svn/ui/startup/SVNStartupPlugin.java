package org.eclipse.team.svn.ui.startup;

import org.eclipse.ui.plugin.AbstractUIPlugin;

public class SVNStartupPlugin extends AbstractUIPlugin {

	public SVNStartupPlugin() {
	}

}
